<?php
$a=$_GET['a'];
$b=$_GET['b'];
echo $a+$b;
?>